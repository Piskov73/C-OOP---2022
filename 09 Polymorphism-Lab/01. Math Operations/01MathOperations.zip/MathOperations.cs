﻿namespace Operations
{
    public class MathOperations
    {
      
        public int Add(int x, int y)
        {
            return x + y;
        }
        public double Add(double x, double y,double c   )
        {
            return x + y + c;
        }
        public decimal Add(decimal x, decimal y,decimal c)
        {
            return x + y + c;
        }

    }
}
