﻿namespace MilitaryElite.IO.Interfaces
{
    public interface IRead
    {
        string ReadLine();
    }
}
