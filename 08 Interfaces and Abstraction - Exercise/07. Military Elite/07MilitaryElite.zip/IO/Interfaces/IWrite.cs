﻿namespace MilitaryElite.IO.Interfaces
{
    public interface IWrite
    {
        void Write(string value);
        void WriteLine(string value);
    }
}
