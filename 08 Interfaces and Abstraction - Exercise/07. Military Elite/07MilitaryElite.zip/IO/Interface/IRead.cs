﻿namespace MilitaryElite.IO.Interface
{
    public interface IRead
    {
        string ReadLine();
    }
}
