﻿namespace MilitaryElite.Models.Interface
{
    public interface IPrivate :ISoldier
    {
        decimal Salary { get; }
    }
}
