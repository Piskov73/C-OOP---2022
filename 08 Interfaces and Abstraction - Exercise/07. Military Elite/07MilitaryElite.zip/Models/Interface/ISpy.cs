﻿namespace MilitaryElite.Models.Interface
{
    public interface ISpy : ISoldier
    {
        int CodeNumber { get; }
    }
}
