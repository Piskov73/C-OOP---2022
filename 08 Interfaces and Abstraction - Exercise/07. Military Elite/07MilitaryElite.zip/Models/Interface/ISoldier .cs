﻿namespace MilitaryElite.Models.Interface
{
    public interface ISoldier
    {  
        int ID { get; }
        string FirstName { get; }
        string LastName { get; }

    }
}
