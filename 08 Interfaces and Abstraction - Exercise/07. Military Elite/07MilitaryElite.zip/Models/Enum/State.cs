﻿namespace MilitaryElite.Models.Enum
{
    public enum State
    {
        inProgress=0,
        Finished=1,
    }
}
