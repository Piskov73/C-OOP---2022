﻿namespace MilitaryElite.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
