﻿namespace CollectionHierarchy.IO.Interface
{
    public interface IRead
    {
        string ReadLine();
    }
}
