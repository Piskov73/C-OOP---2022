﻿namespace CollectionHierarchy.IO.Interface
{
    public interface IWrite
    {
        void Write(string value);
        void WriteLine(string value);
    }
}
