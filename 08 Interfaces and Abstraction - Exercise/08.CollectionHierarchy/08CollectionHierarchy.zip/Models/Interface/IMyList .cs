﻿namespace CollectionHierarchy.Models.Interface
{
    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
