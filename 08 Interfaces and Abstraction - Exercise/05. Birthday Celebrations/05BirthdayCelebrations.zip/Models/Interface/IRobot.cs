﻿namespace BirthdayCelebrations.Models.Interface
{
    public interface IRobot :IIdentifier
    {
        string Model { get; }
    }
}
