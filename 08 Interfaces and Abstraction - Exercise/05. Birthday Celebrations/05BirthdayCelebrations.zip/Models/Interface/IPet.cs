﻿namespace BirthdayCelebrations.Models.Interface
{
    public interface IPet : IName, IBirthdate
    {
    }
}
