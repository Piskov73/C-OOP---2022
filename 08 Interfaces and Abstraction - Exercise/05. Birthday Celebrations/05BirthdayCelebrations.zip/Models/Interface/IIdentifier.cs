﻿namespace BirthdayCelebrations.Models.Interface
{
    public interface IIdentifier
    {
        string ID { get; }
    }
}
