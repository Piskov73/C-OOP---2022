﻿namespace BirthdayCelebrations.Models.Interface
{
    public interface IName
    {
        string Name { get; }
    }
}
