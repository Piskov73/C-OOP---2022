﻿namespace BirthdayCelebrations.Models.Interface
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
