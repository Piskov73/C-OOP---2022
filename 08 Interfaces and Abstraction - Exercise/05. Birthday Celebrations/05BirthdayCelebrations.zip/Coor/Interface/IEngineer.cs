﻿namespace BirthdayCelebrations.Coor.Interface
{
    public interface IEngineer
    {
        void Run();
    }
}
