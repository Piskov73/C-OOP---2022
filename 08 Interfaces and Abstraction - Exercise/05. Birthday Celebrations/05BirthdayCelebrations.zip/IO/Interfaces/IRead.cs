﻿namespace BirthdayCelebrations.IO.Interfaces
{
    public interface IRead
    {
        string ReadLine();
    }
}
