﻿namespace BirthdayCelebrations.IO.Interfaces
{
    public interface IWrite
    {
        void Write(object text);
        void WriteLine(string text);
    }
}
