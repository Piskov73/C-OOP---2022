﻿namespace BirthdayCelebrations.IO.Interface
{
    public interface IRead
    {
        string ReadLine();
    }
}
