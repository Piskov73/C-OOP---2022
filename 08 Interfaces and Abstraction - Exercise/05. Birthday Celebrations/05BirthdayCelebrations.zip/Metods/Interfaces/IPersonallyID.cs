﻿namespace BirthdayCelebrations.Metods.Interfaces
{
    public interface IPersonallyID
    {
        string ID { get; }
    }
}
