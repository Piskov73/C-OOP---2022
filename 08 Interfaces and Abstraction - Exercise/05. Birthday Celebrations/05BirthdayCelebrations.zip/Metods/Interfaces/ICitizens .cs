﻿namespace BirthdayCelebrations.Metods.Interfaces
{
    public interface ICitizens 
    {
       
        string Name { get; }
        int Age { get; }
    }
}
