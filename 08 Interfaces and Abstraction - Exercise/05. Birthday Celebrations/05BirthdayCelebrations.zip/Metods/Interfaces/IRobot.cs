﻿namespace BirthdayCelebrations.Metods.Interfaces
{
    public interface IRobot
    {
        string Model { get; }
    }
}
