﻿namespace BirthdayCelebrations.Metods.Interfaces
{
    public interface IPet 
    {
        string Name { get; }
    }
}
