﻿namespace BirthdayCelebrations.Metods.Interfaces
{
    public interface IBirthday
    {
        string Birthday { get; }
    }
}
