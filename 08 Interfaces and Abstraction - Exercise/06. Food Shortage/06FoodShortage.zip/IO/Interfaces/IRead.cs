﻿namespace FoodShortage.IO.Interfaces
{
    public interface IRead
    {
        string Read();
    }
}
