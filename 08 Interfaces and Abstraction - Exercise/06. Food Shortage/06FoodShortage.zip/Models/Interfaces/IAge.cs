﻿namespace _06FoodShortage.Models.Interfaces
{
    public interface IAge
    {
        int Age { get; }
    }
}
