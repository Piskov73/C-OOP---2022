﻿namespace _06FoodShortage.Models.Interfaces
{
    public interface ICitizen
    {
        string Id { get; }
        string Brithdate { get; }
    }
}
