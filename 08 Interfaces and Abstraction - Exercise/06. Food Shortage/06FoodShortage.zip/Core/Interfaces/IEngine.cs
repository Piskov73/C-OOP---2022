﻿namespace _06FoodShortage.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
