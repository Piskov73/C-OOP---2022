﻿namespace BorderControl.Models.Interfaces
{
    public interface IRobots : IPopulation
    {
        string Model { get; }
      
    }
}
