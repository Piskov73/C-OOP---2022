﻿
namespace BorderControl.Models.Interfaces
{
    public interface IPopulation
    {
        string Id { get; }
    }
}
