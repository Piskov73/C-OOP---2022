﻿namespace BorderControl.Coor.Interfaces
{
    internal interface IEngineer
    {
        void Run();
    }
}
