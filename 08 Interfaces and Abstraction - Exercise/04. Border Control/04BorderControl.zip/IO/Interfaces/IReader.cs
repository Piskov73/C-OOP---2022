﻿using System;

namespace BorderControl.IO.Interfaces
{
    public  interface IReader
    {
        string ReadLine();
    }
}
