﻿namespace Telephony.Models.Interfaces
{
    public interface IStationaryPhone
    {
        string Call(string phoneNumber);
    }
}
