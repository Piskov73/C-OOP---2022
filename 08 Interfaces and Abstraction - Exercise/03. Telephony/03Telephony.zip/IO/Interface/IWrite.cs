﻿namespace Telephony.IO.Interface
{
    public interface IWrite
    {
        void Write(string text);
        void WriteLine(string text);
    }
}
