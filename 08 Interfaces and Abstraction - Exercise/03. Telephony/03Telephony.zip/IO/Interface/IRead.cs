﻿namespace Telephony.IO.Interface
{
    public  interface IRead
    {
        string ReadLain();
    }
}
