﻿namespace Telephony.IO.Interface
{
    public interface IRead
    {
        string ReadLine();
    }
}
