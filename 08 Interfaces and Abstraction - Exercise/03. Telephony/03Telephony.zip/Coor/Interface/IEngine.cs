﻿namespace Telephony.Coor.Interface
{
    public  interface IEngine
    {
        void Run();
    }
}
