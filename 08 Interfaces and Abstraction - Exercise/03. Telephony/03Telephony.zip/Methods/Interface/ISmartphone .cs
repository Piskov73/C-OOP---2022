﻿namespace Telephony.Methods.Interface
{
    public interface ISmartphone : IStationaryPhone
    {
        string Browse(string url);
    }
}
