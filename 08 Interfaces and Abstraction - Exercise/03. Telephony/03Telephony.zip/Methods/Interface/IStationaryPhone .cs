﻿namespace Telephony.Methods.Interface
{
    public interface IStationaryPhone
    {
        string Call(string phoneNumber);
    }
}
