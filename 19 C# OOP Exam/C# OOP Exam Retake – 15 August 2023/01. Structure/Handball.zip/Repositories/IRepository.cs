﻿namespace Handball.Repositories
{
    public interface IRepository
    {
    }
}