﻿namespace PlayersAndMonsters
{
    public class Wizard : Hero
    {
        public Wizard(string username, int leval) : base(username, leval)
        {
        }
    }
}
