﻿namespace PlayersAndMonsters
{
    public class Knight : Hero
    {
        public Knight(string username, int leval) : base(username, leval)
        {
        }
    }
}
