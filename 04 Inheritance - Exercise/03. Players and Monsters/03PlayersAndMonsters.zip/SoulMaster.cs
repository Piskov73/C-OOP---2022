﻿namespace PlayersAndMonsters
{
    public class SoulMaster : DarkWizard
    {
        public SoulMaster(string username, int leval) : base(username, leval)
        {
        }
    }
}
