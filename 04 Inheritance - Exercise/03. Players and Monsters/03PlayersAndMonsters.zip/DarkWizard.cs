﻿namespace PlayersAndMonsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string username, int leval) : base(username, leval)
        {
        }
    }
}
