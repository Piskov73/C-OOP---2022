﻿namespace PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string username, int leval) : base(username, leval)
        {
        }
    }
}
