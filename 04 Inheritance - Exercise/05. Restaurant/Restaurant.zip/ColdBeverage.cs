﻿namespace Restaurant
{
    public class ColdBeverage : Beverage
    {
        public ColdBeverage(string name, decimal price, double millilitres) : base(name, price, millilitres)
        {
        }
    }
}
