﻿namespace Cars
{
    public interface ICar
    {
      public  string Model { get; }
      public  string Color { get; }
        void Start();
       void Stop();

    }
}
