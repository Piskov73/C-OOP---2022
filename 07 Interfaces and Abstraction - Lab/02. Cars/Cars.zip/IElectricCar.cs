﻿namespace Cars
{
    public interface IElectricCar : ICar
    {
        public int Batteries { get; }

    }
}
