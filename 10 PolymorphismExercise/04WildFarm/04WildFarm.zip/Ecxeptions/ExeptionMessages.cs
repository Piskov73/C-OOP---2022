﻿namespace WildFarm.Ecxeptions
{
    public static class ExeptionMessages
    {
        public const string ANIMAL_NOT_EAT = "{0} does not eat {1}!";
    }
}
