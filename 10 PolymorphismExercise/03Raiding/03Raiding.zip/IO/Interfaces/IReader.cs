﻿namespace Raiding.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();

    }
}
