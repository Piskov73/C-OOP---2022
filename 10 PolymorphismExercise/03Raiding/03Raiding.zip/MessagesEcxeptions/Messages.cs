﻿namespace Raiding.MessagesEcxeptions
{
    public static class Messages
    {
        public const string INVALID_HERO = "Invalid hero!";
    }
}
