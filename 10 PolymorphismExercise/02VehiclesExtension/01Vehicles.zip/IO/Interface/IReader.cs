﻿namespace Vehicles.IO.Interface
{
    public interface IReader
    {
        string ReadLine();
    }
}
