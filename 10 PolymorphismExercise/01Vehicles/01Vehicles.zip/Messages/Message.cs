﻿namespace Vehicles.Messages
{
    public static class Message
    {
        public const string NeedsRefueling = "{0} needs refueling";
    }
}
