﻿namespace Vehicles.Messages
{
    public static class EcxeptionMessage
    {
        public const string NEEDS_REFUELING = "{0} needs refueling";
        public const string INVALID_VEHICLE = "Invalid vehicle !!!";
        public const string INVALID_COMMAND = "Invalid  command !!!";
    }
}
