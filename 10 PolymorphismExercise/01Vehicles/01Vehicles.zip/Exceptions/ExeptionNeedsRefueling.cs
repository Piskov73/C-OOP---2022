﻿namespace Vehicles.Exceptions
{
using System;
    public class ExeptionNeedsRefueling : Exception
    {
        
       
        public ExeptionNeedsRefueling(string message) : base(message)
        {
            
        }


    }
}
