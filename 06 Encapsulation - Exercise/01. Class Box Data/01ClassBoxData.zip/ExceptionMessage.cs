﻿namespace _01ClassBoxData
{
    public static class ExceptionMessage
    {
        public const string CANNOT_ZERO_NEGATIVE_NUMBER = "{0} cannot be zero or negative.";
    }
}
