﻿namespace ClassBoxData
{
    public static class MessageException
    {
        public const string THE_NUMBER_CANNOT_BE_ZERO_AND_NEGATIVE = "{0} cannot be zero or negative.";
    }
}
