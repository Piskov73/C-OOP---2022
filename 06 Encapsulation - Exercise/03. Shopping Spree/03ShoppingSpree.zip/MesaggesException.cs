﻿namespace ShoppingSpree
{
    public static class MesaggesException
    {
        public const string INVALID_NAME = "Name cannot be empty";
        public const string INVALID_COST = "Money cannot be negative";
        public const string INVALID_PERSON = "Invalid person!";
        public const string INVALID_PRODUCT = "Invalid product!";

    }
}
