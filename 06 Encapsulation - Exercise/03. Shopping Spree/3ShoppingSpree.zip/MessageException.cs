﻿namespace _3ShoppingSpree
{
    public static class MessageException
    {
        public const string CANNOT_BE_EMPTY = "Name cannot be empty";

        public const string CANNOT_BE_NEGATIVE = "Money cannot be negative";
    }
}
